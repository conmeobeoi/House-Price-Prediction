import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import math

class VirtualRuler:
    def __init__(self, master):
        self.master = master
        self.master.title("Virtual Ruler with Menu Bar")
        self.master.geometry("900x700")
        self.master.minsize(500, 400)
        self.master.configure(bg="#f9f9f9")

        self.canvas = tk.Canvas(master, bg="white", cursor="cross", relief="groove", bd=2)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=10)

        self.image = None
        self.img_tk = None
        self.points = []
        self.measure_mode = None
        self.temp_line = None
        self.temp_distance_text = None
        self.history = []
        self.redo_stack = []
        self.scale_factor = 1
        self.scale_unit = "um"

        self.menu_bar = tk.Menu(master)
        master.config(menu=self.menu_bar)

        # File menu
        file_menu = tk.Menu(self.menu_bar, tearoff=0)
        file_menu.add_command(label="Open", command=self.load_image)
        file_menu.add_command(label="Save", command=self.save_image)
        # file_menu.add_command(label="Delete Last", command=self.delete_last)
        # file_menu.add_command(label="Delete All", command=self.delete_all)
        self.menu_bar.add_cascade(label="File", menu=file_menu)

        edit_menu = tk.Menu(self.menu_bar, tearoff=0)
        edit_menu.add_command(label="Undo", command=self.undo)
        edit_menu.add_command(label="Redo", command=self.redo)
        self.menu_bar.add_cascade(label="Edit", menu=edit_menu)

        mode_menu = tk.Menu(self.menu_bar, tearoff=0)
        mode_menu.add_command(label="Horizontal", command=self.set_horizontal_mode)
        mode_menu.add_command(label="Vertical", command=self.set_vertical_mode)
        mode_menu.add_command(label="Free", command=self.set_free_mode)
        self.menu_bar.add_cascade(label="Mode", menu=mode_menu)

        self.label = tk.Label(master, text="Select points to measure the distance", font=("Arial", 14), bg="#f9f9f9")
        self.label.pack(pady=10, fill="x", anchor="center")  
        self.scale_frame = tk.Frame(master, bg="#f9f9f9")
        self.scale_frame.pack(fill="x", padx=15, pady=(5, 10)) 

        self.scale_frame.grid_columnconfigure(0, weight=1)  
        self.scale_frame.grid_columnconfigure(1, weight=1)  
        self.scale_frame.grid_columnconfigure(2, weight=1)  
        self.scale_frame.grid_columnconfigure(3, weight=1)  
        self.scale_frame.grid_columnconfigure(4, weight=1)  

        self.scale_label = tk.Label(self.scale_frame, text="Scale Factor:", font=("Arial", 12), bg="#f9f9f9")
        self.scale_label.grid(row=0, column=0, padx=5, pady=5, sticky="ew")  

        self.scale_entry = tk.Entry(self.scale_frame, font=("Arial", 12))
        self.scale_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")  
        self.scale_entry.insert(0, str(self.scale_factor))  

        self.unit_label = tk.Label(self.scale_frame, text="Unit (per pixel):", font=("Arial", 12), bg="#f9f9f9")
        self.unit_label.grid(row=0, column=2, padx=5, pady=5, sticky="ew")  

        self.unit_var = tk.StringVar(value=self.scale_unit)
        self.unit_menu = tk.OptionMenu(self.scale_frame, self.unit_var, "mm", "um")
        self.unit_menu.grid(row=0, column=3, padx=5, pady=5, sticky="ew")  

        self.apply_button = tk.Button(self.scale_frame, text="Apply", command=self.apply_scale, font=("Arial", 12), bg="#4CAF50", fg="white")
        self.apply_button.grid(row=0, column=4, padx=10, pady=5, sticky="ew") 

        self.scale_frame.grid_rowconfigure(0, weight=1)

        self.canvas.bind("<Button-1>", self.on_canvas_click)
        self.canvas.bind("<Motion>", self.on_canvas_motion)
        self.master.bind("<Configure>", self.on_window_resize)



    def load_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp;*.gif")])
        if file_path:
            self.image = Image.open(file_path)
            self.image = self.image.convert("RGBA")
            self.scale_factor = 1  # Reset scale factor
            self.display_image()

    def save_image(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".png",
                                                filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg"), ("All files", "*.*")])
        if file_path:
            if self.image:
                img_copy = self.image.copy()
                
                from PIL import ImageDraw
                
                draw = ImageDraw.Draw(img_copy)
                
                for item_id in self.history:
                    if self.canvas.type(item_id) == "line":
                        coords = self.canvas.coords(item_id)
                        draw.line(coords, fill="blue", width=3)
                    elif self.canvas.type(item_id) == "text":
                        coords = self.canvas.coords(item_id)
                        text = self.canvas.itemcget(item_id, "text")
                        draw.text((coords[0], coords[1]), text, fill="blue")

                # Save the new image with the drawn lines
                img_copy.save(file_path)
                messagebox.showinfo("Save Image", "Image saved successfully with drawn lines!")
            else:
                messagebox.showwarning("Save Image", "No image to save!")


    # def delete_last(self):
    #     if self.history:
    #         last_action = self.history.pop()
    #         self.redo_stack.append(last_action)
    #         self.canvas.delete(last_action)
    #     else:
    #         messagebox.showwarning("Delete Last", "No actions to undo!")

    # def delete_all(self):
    #     self.canvas.delete("all")
    #     if self.img_tk:
    #         self.canvas.create_image(0, 0, anchor="nw", image=self.img_tk)
    #     self.history.clear()
    #     self.redo_stack.clear()

    def undo(self):
        num_actions_to_undo = 3
        for _ in range(num_actions_to_undo):
            if self.history:
                last_action = self.history.pop()
                self.redo_stack.append(last_action)
                self.canvas.delete(last_action)
            else:
                messagebox.showwarning("Undo", "No actions to undo!")
                break

    def redo(self):
        if self.redo_stack:
            action = self.redo_stack.pop()
            self.history.append(action)
            self.canvas.itemconfigure(action, state="normal")
        else:
            messagebox.showwarning("Redo", "No actions to redo!")

    def on_canvas_click(self, event):
        if self.measure_mode == "horizontal":
            self.measure_horizontal(event.x, event.y)
        elif self.measure_mode == "vertical":
            self.measure_vertical(event.x, event.y)
        elif self.measure_mode == "free":
            self.points.append((event.x, event.y))
            point_id = self.canvas.create_oval(event.x - 5, event.y - 5, event.x + 5, event.y + 5, fill="red")
            self.history.append(point_id)
            if len(self.points) == 2:
                self.show_distance()

    def on_canvas_motion(self, event):
        if self.measure_mode == "free":
            if len(self.points) == 1:
                if self.temp_line:
                    self.canvas.delete(self.temp_line)
                if self.temp_distance_text:
                    self.canvas.delete(self.temp_distance_text)

                x1, y1 = self.points[0]

                self.temp_line = self.canvas.create_line(x1, y1, event.x, event.y, fill="blue", dash=(4, 2), width=2)



        elif self.measure_mode in ["horizontal", "vertical"]:
            if len(self.points) == 1:
                if self.temp_line:
                    self.canvas.delete(self.temp_line)
                if self.temp_distance_text:
                    self.canvas.delete(self.temp_distance_text)

                x1, y1 = self.points[0]

                if self.measure_mode == "horizontal":
                    self.temp_line = self.canvas.create_line(x1, y1, event.x, y1, fill="blue", dash=(4, 2), width=2)
                elif self.measure_mode == "vertical":
                    self.temp_line = self.canvas.create_line(x1, y1, x1, event.y, fill="blue", dash=(4, 2), width=2)

    

    def show_distance(self):
        if len(self.points) == 2:
            x1, y1 = self.points[0]
            x2, y2 = self.points[1]
            
            pixel_distance = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
            
            real_distance = pixel_distance * self.scale_factor
            self.label.config(text=f"Distance: {real_distance:.2f} {self.scale_unit}")
            
            line_id = self.canvas.create_line(x1, y1, x2, y2, fill="blue", width=2)
            self.history.append(line_id)
            
            mid_x = (x1 + x2) / 2
            mid_y = (y1 + y2) / 2
            
            vertical_offset = 20  
            
            distance_text_id = self.canvas.create_text(mid_x, mid_y + vertical_offset, 
                                                        text=f"{real_distance:.2f} {self.scale_unit}", 
                                                        fill="blue", angle=90)  # Rotate text 90 degrees
            self.history.append(distance_text_id)
            
            self.points = []
    def measure_horizontal(self, x, y):
        if len(self.points) == 0:
            self.points.append((x, y))
            point_id = self.canvas.create_oval(x - 5, y - 5, x + 5, y + 5, fill="red")
            self.history.append(point_id)
            self.label.config(text="Click the second point for horizontal distance")
        elif len(self.points) == 1:
            x1, y1 = self.points[0]
            y = y1  
            point_id = self.canvas.create_oval(x - 5, y - 5, x + 5, y + 5, fill="red")
            self.history.append(point_id)

            pixel_distance = abs(x - x1)
            real_distance = pixel_distance * self.scale_factor
            self.label.config(text=f"Horizontal distance: {real_distance:.2f} {self.scale_unit}")

            line_id = self.canvas.create_line(x1, y1, x, y, fill="green", width=2)
            self.history.append(line_id)
            distance_text_id = self.canvas.create_text((x1 + x) / 2, y, text=f"{real_distance:.2f} {self.scale_unit}", fill="green")
            self.history.append(distance_text_id)

            self.points = []  
    def measure_vertical(self, x, y):
        if len(self.points) == 0:
            self.points.append((x, y))
            point_id = self.canvas.create_oval(x - 5, y - 5, x + 5, y + 5, fill="red")
            self.history.append(point_id)
            self.label.config(text="Click the second point for vertical distance")
        elif len(self.points) == 1:
            x1, y1 = self.points[0]
            x = x1  
            point_id = self.canvas.create_oval(x - 5, y - 5, x + 5, y + 5, fill="red")
            self.history.append(point_id)

            pixel_distance = abs(y - y1)
            real_distance = pixel_distance * self.scale_factor
            self.label.config(text=f"Vertical distance: {real_distance:.2f} {self.scale_unit}")

            line_id = self.canvas.create_line(x1, y1, x, y, fill="orange", width=2)
            self.history.append(line_id)
            distance_text_id = self.canvas.create_text(x, (y1 + y) / 2, text=f"{real_distance:.2f} {self.scale_unit}", fill="orange")
            self.history.append(distance_text_id)

            self.points = []  

    def set_horizontal_mode(self):
        self.measure_mode = "horizontal"
        self.label.config(text="Click to select the first point (horizontal measurement)")

    def set_vertical_mode(self):
        self.measure_mode = "vertical"
        self.label.config(text="Click to select the first point (vertical measurement)")

    def set_free_mode(self):
        self.measure_mode = "free"
        self.label.config(text="Click to select the first point, then move the mouse for real-time distance measurement")

    def apply_scale(self):
        try:
            new_scale = float(self.scale_entry.get())
            new_unit = self.unit_var.get()
            self.scale_factor = new_scale
            self.scale_unit = new_unit
            self.label.config(text=f"Scale applied: {new_scale} {new_unit}/pixel")
        except ValueError:
            messagebox.showwarning("Invalid Input", "Please enter a valid scale value.")

    def display_image(self):
        if self.image:
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()

            img_width, img_height = self.image.size
            aspect_ratio = img_width / img_height

            if canvas_width / aspect_ratio <= canvas_height:
                new_width = canvas_width
                new_height = int(new_width / aspect_ratio)
            else:
                new_height = canvas_height
                new_width = int(new_height * aspect_ratio)

            self.image = self.image.resize((new_width, new_height))
            self.img_tk = ImageTk.PhotoImage(self.image)

            x_offset = (canvas_width - new_width) // 2
            y_offset = (canvas_height - new_height) // 2

            self.canvas.create_image(x_offset, y_offset, anchor="nw", image=self.img_tk)
            self.points = []  

    def on_window_resize(self, event):
        self.display_image()  
        

if __name__ == "__main__":
    root = tk.Tk()
    ruler = VirtualRuler(root)
    root.mainloop()
